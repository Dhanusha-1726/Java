#include<stdio.h>
int main(){
    int n,r,m;
    int sum=0;
    scanf("%d",&n);
    int temp=n;
    int s=n;
    int c=0;
    while(n>0){
        m=n%10;
        c++;
        n=n/10;
    }
    printf("%d\n",c);
    
    while(temp>0){
       r=temp%10;
       int k=1;
       for(int i=1;i<=c;i++){
        k=k*r;
       }
       sum+=k;
        temp=temp/10;
    }
    
   if(s==sum){
       printf("amstrong number");
   }
   else{
       printf("not a amstrong number");
   }
 }


    
    